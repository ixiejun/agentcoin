set -e
cd /root/autodl-tmp/agentcoin
export HF_HUB_DISABLE_XET=1 HF_HUB_OFFLINE=1 VLLM_USE_V2_MODEL_RUNNER=0
export CUDA_HOME=/root/autodl-tmp/agentcoin-gpu/venv/lib/python3.12/site-packages/nvidia/cu13 PATH=/root/autodl-tmp/agentcoin-gpu/venv/lib/python3.12/site-packages/nvidia/cu13/bin:$PATH
S=scripts/gpu-calibration.sh
echo "== check $(date)"; $S check
echo "== generate $(date)"; $S generate
ls /root/autodl-tmp/agentcoin-gpu
B=$(ls -d /root/autodl-tmp/agentcoin-gpu/bundle-*-seed* | grep -v '\.tar\.gz$' | head -1)
echo "== recheck $B $(date)"; $S recheck "$B"
echo "== pack $(date)"; $S pack
ls -la /root/autodl-tmp/agentcoin-gpu/out
echo "== ALL-OWN-DONE $(date)"
