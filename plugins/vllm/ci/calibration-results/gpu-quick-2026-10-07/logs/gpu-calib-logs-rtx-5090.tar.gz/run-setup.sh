set -e
source /etc/network_turbo
export no_proxy="$no_proxy,pypi.tuna.tsinghua.edu.cn,hf-mirror.com,rsproxy.cn"
export NO_PROXY="$no_proxy"
cd /root/autodl-tmp
[ -d agentcoin ] || git clone https://github.com/ixiejun/agentcoin.git
cd agentcoin
git fetch origin claude/determined-johnson-f8thb8 || true
git checkout claude/determined-johnson-f8thb8
git pull --ff-only origin claude/determined-johnson-f8thb8 || true
git log --oneline -1
export PIP_INDEX_URL=https://pypi.tuna.tsinghua.edu.cn/simple
export CARGO_MIRROR=sparse+https://rsproxy.cn/index/
export RUSTUP_DIST_SERVER=https://rsproxy.cn RUSTUP_UPDATE_ROOT=https://rsproxy.cn/rustup
export HF_HUB_DISABLE_XET=1
W=/root/autodl-tmp/agentcoin-gpu/wheels/vllm-0.30.0-cp38-abi3-manylinux_2_28_x86_64.whl
if ! echo "ef52ee58c410ead0b8afb190838fa4cbcb52075596f67862a03859d984966ac4  $W" | sha256sum -c --quiet 2>/dev/null; then
  rm -f "$W"; mkdir -p "$(dirname "$W")"
  curl -fL --retry 3 -sS -o "$W" https://pypi.tuna.tsinghua.edu.cn/packages/1a/25/f5087a8f382e197a73672768b389d020b9d92e38371c3b0fc6dd883bbb34/vllm-0.30.0-cp38-abi3-manylinux_2_28_x86_64.whl
  echo "wheel downloaded from the tuna mirror"
fi
bash /root/autodl-tmp/prefetch-models.sh
scripts/gpu-calibration.sh setup
