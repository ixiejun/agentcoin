# Prefetch the pinned models' model.safetensors from ModelScope into the HF cache.
# Each blob is checked against the SHA-256 that the HF mirror lists (x-linked-etag);
# verify-model.py then checks the whole snapshot digest anyway.
set -e
export HF_HOME=/root/autodl-tmp/agentcoin-gpu/hf
prefetch() {
  repo=$1; rev=$2
  sha=$(env -u http_proxy -u https_proxy curl -sI "https://hf-mirror.com/$repo/resolve/$rev/model.safetensors" | grep -i '^x-linked-etag' | tr -d '"\r' | awk '{print $2}')
  [ ${#sha} -eq 64 ] || { echo "no sha for $repo"; return 1; }
  d=$HF_HOME/hub/models--${repo/\//--}
  mkdir -p "$d/blobs" "$d/snapshots/$rev"
  find "$d/blobs" -name '*.incomplete' -delete
  b=$d/blobs/$sha
  if ! echo "$sha  $b" | sha256sum -c --quiet 2>/dev/null; then
    env -u http_proxy -u https_proxy curl -fL --retry 3 -sS -o "$b.tmp" "https://modelscope.cn/models/$repo/resolve/master/model.safetensors"
    echo "$sha  $b.tmp" | sha256sum -c --quiet && mv "$b.tmp" "$b"
  fi
  ln -sfn "../../blobs/$sha" "$d/snapshots/$rev/model.safetensors"
  echo "OK $repo@$rev model.safetensors sha256=$sha"
}
prefetch Qwen/Qwen2.5-0.5B-Instruct 7ae557604adf67be50417f59c2c2f167def9a775
prefetch Qwen/Qwen2.5-0.5B 060db6499f32faf8b98477b0a26969ef7d8b9987
